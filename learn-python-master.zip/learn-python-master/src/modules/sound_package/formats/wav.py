"""WAV file support."""


def wav_read():
    """WAV file reading function mock"""
    return 'Read from WAV file'
